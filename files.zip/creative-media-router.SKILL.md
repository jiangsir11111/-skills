---
name: creative-media-router
description: >-
  当用户要求生成图片、画图、做视频、做动画/动图，或给出
  mode=text/image/video 这类多媒体生成请求时使用本skill，
  用于判断应调用哪个当前真实可用的工具或Skill完成任务——
  image_search做图片检索、Visualizer做插图与图表、
  algorithmic-art做生成式美术、canvas-design做海报设计、
  slack-gif-creator做动图——而不是假设系统内置了一个统一的
  “AI图像/视频生成API”。当用户上传了类似media-generator的
  接口文档并要求据此实现功能，或某个请求在文本回复与图像/
  视频生成之间的最佳呈现方式不明确时，也应主动参考本skill。
metadata:
  adapted_from: "media-generator (text/image/video mode interface draft)"
  version: "1.0"
---

# Creative Media Router

把“按 `mode` 路由”这一思路，从一份假设了通用 AI 图像/视频生成 API 的接口文档草案，
重新映射到当前环境**真实存在**的工具与 Skill 上。

## 核心原则

1. **不要假装调用一个不存在的生成接口。** 原文档的 `examples` 里出现的
   `<image1_url>`、`<video_url_with_subtitles>` 这类占位符，容易诱导出
   “编一个看起来合理的链接/文件名”这种行为——这是必须避免的。
2. **每次使用前，先确认对应工具/Skill 在当前环境中确实存在**
   （尤其是 `algorithmic-art`、`canvas-design`、`slack-gif-creator`，
   以及用户自行安装的 `imagegen` 类 Skill）。不存在就如实说明，
   并给出下面列出的替代方案，而不是硬套。
3. **做不到的部分（尤其真实视频文件、背景音乐、独立字幕轨）直接说做不到**，
   再问用户是否接受替代效果。

## 第一步：判断 mode

把用户请求（或显式传入的 `mode` 参数）归类为：

- **text** —— 要文字回答、解释、建议。
- **image** —— 要“看图”“画一张”“生成/配一张图片”等静态视觉内容。
- **video** —— 要“视频”“动画”“动图”“GIF”等动态内容。

如果请求本身比较模糊（一段描述，没说明要不要配图），先按对话上下文判断
是否需要视觉呈现；本skill主要解决 image/video 两种模式下
**具体该用哪个工具**的问题。

## mode = text

直接以对话形式回答，不需要本skill列出的任何专用工具。若用户提供了
`conversation_context`（额外背景信息），将其作为普通上下文使用即可。

## mode = image：先选子路径，再执行

“AI图像生成”在当前环境里不是单一接口，而是分散在几个工具/Skill里：

| 用户意图 | 对应路径 | 说明 |
|---|---|---|
| 想看某个真实存在的事物/地点/产品/动物的照片 | `image_search` 工具 | 检索网络已有图片；受内容安全限制，不可用于真人、受版权角色等 |
| 需要图表、流程图、UI原型、信息图、数据可视化、交互小工具 | Visualizer（`show_widget`） | 调用前先按需读取对应的 `read_me` 模块（diagram/mockup/chart/interactive） |
| 想要“生成式/算法艺术”，强调随机种子、参数可调、多变体 | `algorithmic-art` Skill | 基于 p5.js；原生对应原文档的 `image_seed`、`image_variations`/`image_count` |
| 想要一张可下载的海报/邀请函/社媒配图等平面设计成品 | `canvas-design` Skill | 产出 png/pdf 静态设计文件 |
| 用户已自行安装第三方“AI绘图”Skill（如 `/mnt/skills/user/imagegen/`） | 该 imagegen Skill | 仅当确实存在该Skill时使用，不要凭空假设它存在 |

`image_style`、`image_resolution` 对 `image_search` 基本无效（检索结果的
风格/尺寸不可控），但对 Visualizer / algorithmic-art / canvas-design
可作为风格与画布尺寸的提示传入。

## mode = video：管理预期，给出可行替代

原文档假设的“AI视频生成”（指定 `video_script`、`duration`、`fps`、
`background_music`、`subtitles`，输出 mp4）**在当前环境不存在**。
可行的替代方案：

| 用户想要 | 可行替代 | 局限 |
|---|---|---|
| 短循环动图，发到聊天工具 | `slack-gif-creator` Skill | 输出GIF；无音频；`video_script`/`keyframes` 可拆解为帧序列 |
| 网页端的动画/转场效果演示 | Visualizer（HTML/CSS/JS） | 仅可在对话内预览，不能导出为视频文件 |
| 带背景音乐、字幕的成片 mp4/webm | —— | **不支持**，如实告知，并提供以上两种替代之一 |

`background_music` 和独立意义上的 `subtitles`（字幕轨）目前都做不到；
如果用户坚持要“视频”，先确认对方是否接受 GIF 或网页动画作为替代，再动手。

## 决策流程图

```mermaid
flowchart TD
    A[用户请求] --> B{判断 mode}
    B -->|text| C["直接对话回复<br/>可结合 conversation_context"]
    B -->|image| D{选择图像路径}
    D -->|检索真实照片/参考图| D1[image_search]
    D -->|图表/原型/数据可视化| D2["Visualizer<br/>show_widget"]
    D -->|生成式/算法艺术/带种子| D3[algorithmic-art skill]
    D -->|海报/平面设计成品| D4[canvas-design skill]
    D -->|已安装第三方AI绘图skill| D5["调用该 imagegen skill"]
    B -->|video| E{选择动态内容路径}
    E -->|短循环动图 GIF| E1[slack-gif-creator skill]
    E -->|网页动画, 仅对话内预览| E2["Visualizer<br/>HTML/CSS/JS"]
    E -->|mp4等含配乐/字幕的视频| E3["不支持<br/>如实告知并给替代方案"]
```

## 原文档参数 → 本skill处理方式 对照表

| 原参数 | 在本skill中的处理 |
|---|---|
| `mode` | 决定走 text / image / video 哪条主路径 |
| `text_prompt` / `conversation_context` | 直接作为对话内容/背景，无需额外工具 |
| `image_prompt` | 传给所选图像路径（检索词 / Visualizer内容 / 艺术描述等） |
| `image_style` | 对 Visualizer / algorithmic-art / canvas-design 作为风格提示；对 image_search 无效 |
| `image_resolution` | 按所选路径自身的画布/尺寸规范设置；image_search结果尺寸不可控 |
| `image_count` / `image_variations` | algorithmic-art / canvas-design 可循环生成多版本；image_search 一次返回3-5张 |
| `image_seed` | 仅 algorithmic-art 原生支持（p5.js seeded randomness） |
| `video_script` / `keyframes` | 拆解为 slack-gif-creator 的帧序列，或 Visualizer 动画的关键帧 |
| `video_duration` / `video_fps` / `video_resolution` | 对应 GIF 或动画画布的时长/帧率/尺寸 |
| `video_style` | 作为风格提示传给所选动态路径 |
| `background_music` | 不支持（无音频生成/合成能力） |
| `subtitles` | 退化为画面内文字叠加，非独立字幕轨 |
| `transitions` | 若所选工具支持，用于规划帧间过渡 |
| `output_format` | gif（slack-gif-creator）/ html交互（Visualizer）；mp4/webm 不支持 |
